/* tslint:disable */
require("./AdvanceSearch.module.css");
const styles = {
  advanceSearch: 'advanceSearch_44ec2131',
  container: 'container_44ec2131',
  row: 'row_44ec2131',
  column: 'column_44ec2131',
  'ms-Grid': 'ms-Grid_44ec2131',
  title: 'title_44ec2131',
  subTitle: 'subTitle_44ec2131',
  description: 'description_44ec2131',
  button: 'button_44ec2131',
  label: 'label_44ec2131'
};

export default styles;
/* tslint:enable */