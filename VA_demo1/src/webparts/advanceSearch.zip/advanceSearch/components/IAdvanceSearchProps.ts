import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IAdvanceSearchProps {
  description: string;
  context:WebPartContext;
}
