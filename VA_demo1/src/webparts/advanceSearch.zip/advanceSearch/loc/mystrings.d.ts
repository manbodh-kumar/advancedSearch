declare interface IAdvanceSearchWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'AdvanceSearchWebPartStrings' {
  const strings: IAdvanceSearchWebPartStrings;
  export = strings;
}
